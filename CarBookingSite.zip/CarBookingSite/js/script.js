let currentLang = 'en';

const translations = {
    en: {
        langToggle: 'اردو'
    },
    ur: {
        langToggle: 'English'
    }
};

function toggleLanguage() {
    const body = document.body;
    const langToggle = document.getElementById('langToggle');
    
    if (currentLang === 'en') {
        currentLang = 'ur';
        body.classList.add('rtl');
        langToggle.querySelector('.lang-en').style.display = 'none';
        langToggle.querySelector('.lang-ur').style.display = 'inline';
    } else {
        currentLang = 'en';
        body.classList.remove('rtl');
        langToggle.querySelector('.lang-en').style.display = 'inline';
        langToggle.querySelector('.lang-ur').style.display = 'none';
    }
    
    updateContent();
}

function updateContent() {
    const elements = document.querySelectorAll('[data-en]');
    
    elements.forEach(element => {
        const text = currentLang === 'en' ? element.getAttribute('data-en') : element.getAttribute('data-ur');
        
        if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
            element.placeholder = text;
        } else if (element.tagName === 'OPTION') {
            element.textContent = text;
        } else {
            element.textContent = text;
        }
    });
}

function getFormData() {
    const fromCity = document.getElementById('fromCity').value;
    const toCity = document.getElementById('toCity').value;
    const dateTime = document.getElementById('dateTime').value;
    const vehicle = document.getElementById('vehicle').value;
    const name = document.getElementById('name').value;
    const countryCode = document.getElementById('countryCode').value;
    const phone = document.getElementById('phone').value;
    const notes = document.getElementById('notes').value;
    
    if (!fromCity || !toCity || !dateTime || !vehicle || !name || !phone) {
        alert(currentLang === 'en' ? 'Please fill all required fields' : 'براہ کرم تمام ضروری فیلڈز پُر کریں');
        return null;
    }
    
    return {
        fromCity,
        toCity,
        dateTime,
        vehicle,
        name,
        phone: countryCode + phone,
        notes
    };
}

function sendWhatsApp() {
    const data = getFormData();
    if (!data) return;
    
    const message = `*New Booking Request*\n\n*From:* ${data.fromCity}\n*To:* ${data.toCity}\n*Date & Time:* ${data.dateTime}\n*Vehicle:* ${data.vehicle}\n*Name:* ${data.name}\n*Phone:* ${data.phone}\n*Notes:* ${data.notes || 'None'}`;
    
    const whatsappUrl = `https://wa.me/923208533449?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
}

function sendEmail() {
    const data = getFormData();
    if (!data) return;
    
    const subject = 'New Booking Request - Al Ziyara Transport';
    const body = `New Booking Request\n\nFrom: ${data.fromCity}\nTo: ${data.toCity}\nDate & Time: ${data.dateTime}\nVehicle: ${data.vehicle}\nName: ${data.name}\nPhone: ${data.phone}\nNotes: ${data.notes || 'None'}`;
    
    const mailtoUrl = `mailto:alziyaratransport@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.location.href = mailtoUrl;
}

document.addEventListener('DOMContentLoaded', function() {
    const langToggle = document.getElementById('langToggle');
    const whatsappBtn = document.getElementById('whatsappBtn');
    const emailBtn = document.getElementById('emailBtn');
    
    langToggle.addEventListener('click', toggleLanguage);
    whatsappBtn.addEventListener('click', sendWhatsApp);
    emailBtn.addEventListener('click', sendEmail);
    
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
});
